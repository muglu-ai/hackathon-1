class Digest:
    pass